import { NextRequest, NextResponse } from "next/server";
import { clearAuthCookies } from "@/lib/auth";
import { NO_STORE_HEADERS } from "@/lib/http";

export async function POST(request: NextRequest) {
  await clearAuthCookies();
  return NextResponse.redirect(new URL("/login", request.url), { headers: NO_STORE_HEADERS });
}
