import { notFound } from "next/navigation";
import { requireOperator } from "@/lib/auth";
import { getCRMRepository } from "@/lib/crm";
import { maskDestination, proposalUrl } from "@/lib/presentation";

export const dynamic = "force-dynamic";

export default async function LeadPage({ params }: { params: Promise<{ slug: string }> }) {
  await requireOperator();
  const { slug } = await params;
  const repo = getCRMRepository();
  const lead = await repo.getLead(slug);
  if (!lead) notFound();
  const history = await repo.getOutreachHistory(slug);
  const proposal = proposalUrl(lead);

  const fields = [
    ["Status", lead.status], ["Nicho", lead.nicho], ["Cidade", lead.cidade], ["País / locale", [lead.country, lead.locale].filter(Boolean).join(" · ")],
    ["Website status", lead.websiteStatus], ["Site mode", lead.siteMode], ["Nota / avaliações", lead.nota == null ? null : `${lead.nota} / ${lead.avaliacoes ?? "—"}`],
    ["Observações", lead.obs], ["Contrato", lead.contratoStatus], ["Contrato em", lead.contratoEm], ["Valor", lead.valor], ["Manutenção", lead.manutencao],
    ["Pagamento", lead.pago ? "pago" : "não pago"], ["Atualizado", lead.atualizado],
  ] as const;

  return (
    <main className="shell stack">
      <div className="topbar"><div><span className="badge">PREVIEW CRM COPY</span><h1 className="title">{lead.nome ?? lead.slug}</h1><div className="subtle">{lead.slug}</div></div><a className="button" href="/">← Leads</a></div>
      <div className="warning">Read-only preview. Changes here are not canonical.</div>
      <section className="card"><h2 className="section-title">Lead</h2><dl className="grid">{fields.map(([label, value]) => <div className="field" key={label}><dt>{label}</dt><dd>{value == null || value === "" ? "—" : String(value)}</dd></div>)}</dl></section>
      <section className="card"><h2 className="section-title">Links</h2><div className="actions">{proposal && <a className="button" href={proposal} target="_blank" rel="noreferrer">ver proposta ↗</a>}{lead.urlNova && <a className="button" href={lead.urlNova} target="_blank" rel="noreferrer">site publicado ↗</a>}{lead.siteAntigo && <a className="button" href={lead.siteAntigo} target="_blank" rel="noreferrer">site anterior ↗</a>}</div></section>
      <section className="card"><h2 className="section-title">Outreach review</h2><p className="subtle">Sending is disabled in hosted preview.</p><dl className="grid"><div className="field"><dt>Email</dt><dd>{maskDestination(lead.email) ?? "—"}</dd></div><div className="field"><dt>WhatsApp</dt><dd>{maskDestination(lead.whatsapp) ?? "—"}</dd></div><div className="field"><dt>History</dt><dd>{history.length} records</dd></div><div className="field"><dt>Action</dt><dd>Review only — no send endpoint</dd></div></dl></section>
    </main>
  );
}
