import { LeadTable } from "@/components/LeadTable";
import { requireOperator } from "@/lib/auth";
import { getCRMRepository } from "@/lib/crm";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const operator = await requireOperator();
  const leads = await getCRMRepository().listLeads();
  const writeEnabled = process.env.CRM_WRITE_ENABLED === "true";

  return (
    <main className="shell">
      <div className="topbar">
        <div><span className="badge">PREVIEW CRM COPY</span><h1 className="title">Prospector</h1><div className="subtle">Operador: {operator.email}</div></div>
        <form action="/api/auth/logout" method="post"><button className="button" type="submit">Sair</button></form>
      </div>
      <div className="warning">
        Local SQLite remains canonical. {writeEnabled ? "Preview database changes are not synced to local CRM." : "Hosted preview is read-only."}
      </div>
      <LeadTable leads={leads} />
    </main>
  );
}
